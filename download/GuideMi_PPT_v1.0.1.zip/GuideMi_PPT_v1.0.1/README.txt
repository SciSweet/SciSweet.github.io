=========================================
  GuideMi for PowerPoint — Installation
=========================================

Step 1: Unblock the installer
-----------------------------
Windows blocks files downloaded from the internet.
Before running the installer, right-click the .exe file
→ Properties → check "Unblock" at the bottom → OK.

Step 2: Run the installer
-------------------------
Double-click GuideMi_PPT_v*_Setup.exe and follow the prompts.

Step 3: Enable the add-in in PowerPoint
----------------------------------------
If the SciSuite tab does not appear in the ribbon after installation:
1. Open PowerPoint
2. Go to File → Options → Add-ins
3. At the bottom, set "Manage" to "COM Add-ins" → click "Go..."
4. Check the box next to "GuideMi" (or "SciSuite") → OK
5. The SciSuite tab should now appear in the ribbon.
