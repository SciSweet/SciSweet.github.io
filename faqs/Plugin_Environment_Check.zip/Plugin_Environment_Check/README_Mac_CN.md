# CEP 插件环境检测 — Mac 使用说明

## 直接双击运行

双击 `Plugin_Environment_Check_Mac.command` 即可运行。

## 如果 macOS 弹出安全警告

macOS 可能提示"无法验证开发者"或"可能包含恶意软件"，这是因为脚本未经 Apple 签名，并非安全问题。请改用终端（Terminal）运行：

1. 打开 **终端**（在"应用程序 → 实用工具"中，或用 Spotlight 搜索 `Terminal`）
2. 输入以下命令并按回车：

```
bash ~/Downloads/Plugin_Environment_Check_Mac.command
```

> 如果文件不在"下载"文件夹，请将上面的路径替换为文件的实际位置。
> 也可以先输入 `bash `（注意 bash 后面有一个空格），然后把文件直接拖进终端窗口，路径会自动填入，再按回车即可。

3. 运行结束后，将终端中的输出结果截图发送给开发者。
