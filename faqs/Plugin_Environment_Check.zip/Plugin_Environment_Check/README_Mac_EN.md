# CEP Plugin Environment Check — Mac Instructions

## Run by double-clicking

Double-click `Plugin_Environment_Check_Mac.command` to run.

## If macOS shows a security warning

macOS may warn that it "cannot verify the developer" or that the file "may contain malware." This is because the script is not signed by Apple — it is not a security issue. Please use Terminal instead:

1. Open **Terminal** (in Applications → Utilities, or search `Terminal` with Spotlight)
2. Type the following command and press Enter:

```
bash ~/Downloads/Plugin_Environment_Check_Mac.command
```

> If the file is not in your Downloads folder, replace the path with the actual file location.
> Alternatively, type `bash ` (note the space after bash), then drag and drop the file into the Terminal window — the path will be filled in automatically — and press Enter.

3. After it finishes, take a screenshot of the Terminal output and send it to the developer.
