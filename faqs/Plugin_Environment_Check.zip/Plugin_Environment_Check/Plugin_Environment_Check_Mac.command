#!/bin/bash

echo "============================================"
echo "       CEP Plugin Environment Check"
echo "============================================"
echo ""

CC_FOUND=0
CEP_FOUND=0
EXT_SYS=0
EXT_USER=0
PDM_ANY=0
APP_FOUND=0
APP_OLD=0

# ---- Adobe Apps (2022+) ----
echo "[1/5] Checking Adobe Apps..."

for dir in /Applications/Adobe\ */; do
    [ -d "$dir" ] || continue
    name=$(basename "$dir")
    year=""
    for y in 2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028; do
        if echo "$name" | grep -q "$y"; then
            year=$y
        fi
    done
    if [ -n "$year" ]; then
        if [ "$year" -ge 2022 ]; then
            echo "      [OK] $name"
            APP_FOUND=1
        else
            echo "      [OLD] $name (requires 2022 or later)"
            APP_OLD=1
        fi
    fi
done

if [ $APP_FOUND -eq 0 ] && [ $APP_OLD -eq 1 ]; then
    echo "      [!!] Only old Adobe apps found. Plugin requires 2022+."
fi
if [ $APP_FOUND -eq 0 ] && [ $APP_OLD -eq 0 ]; then
    echo "      [!!] No Adobe apps found."
fi
echo ""

# ---- Creative Cloud ----
echo "[2/5] Checking Creative Cloud Desktop App..."

if [ -d "/Applications/Adobe Creative Cloud" ]; then
    echo "      [OK] /Applications/Adobe Creative Cloud"
    CC_FOUND=1
elif [ -d "/Applications/Utilities/Adobe Creative Cloud" ]; then
    echo "      [OK] /Applications/Utilities/Adobe Creative Cloud"
    CC_FOUND=1
fi

if [ $CC_FOUND -eq 0 ]; then
    echo "      [MISSING] Creative Cloud Desktop App NOT found"
    echo "      Plugin installer requires this. Try manual install."
fi
echo ""

# ---- CEPHtmlEngine ----
echo "[3/5] Checking CEPHtmlEngine..."
echo "      Searching... please wait"

while IFS= read -r line; do
    echo "      [OK] $line"
    CEP_FOUND=1
done < <(find /Applications/Adobe* -name "CEPHtmlEngine" -type f 2>/dev/null)

while IFS= read -r line; do
    echo "      [OK] $line"
    CEP_FOUND=1
done < <(find /Library/Application\ Support/Adobe/CEP -name "CEPHtmlEngine" -type f 2>/dev/null)

if [ $CEP_FOUND -eq 0 ]; then
    echo "      [MISSING] CEPHtmlEngine NOT found"
    echo "      CEP plugins CANNOT run. Adobe may be a lite version."
fi
echo ""

# ---- CEP extensions dirs ----
echo "[4/5] Checking CEP extensions directories..."

if [ -d "/Library/Application Support/Adobe/CEP/extensions" ]; then
    echo "      [OK] /Library/Application Support/Adobe/CEP/extensions"
    EXT_SYS=1
fi
if [ -d "$HOME/Library/Application Support/Adobe/CEP/extensions" ]; then
    echo "      [OK] $HOME/Library/Application Support/Adobe/CEP/extensions"
    EXT_USER=1
fi

if [ $EXT_SYS -eq 0 ] && [ $EXT_USER -eq 0 ]; then
    echo "      [MISSING] No CEP extensions directory found"
fi
echo ""

# ---- PlayerDebugMode ----
echo "[5/5] Checking PlayerDebugMode..."

for v in 6 7 8 9 10 11 12; do
    plist="$HOME/Library/Preferences/com.adobe.CSXS.${v}.plist"
    if [ -f "$plist" ]; then
        val=$(defaults read "com.adobe.CSXS.${v}" PlayerDebugMode 2>/dev/null)
        if [ -n "$val" ]; then
            echo "      CSXS.$v = $val"
            PDM_ANY=1
        fi
    fi
done

if [ $PDM_ANY -eq 0 ]; then
    echo "      Not set (OK for signed plugins)"
fi
echo ""

# ---- Summary ----
echo "============================================"
echo "                 SUMMARY"
echo "============================================"
echo ""

if [ $APP_FOUND -eq 1 ]; then
    echo "  Adobe Apps (2022+):  OK"
elif [ $APP_OLD -eq 1 ]; then
    echo "  Adobe Apps:           [TOO OLD] Need 2022 or later"
else
    echo "  Adobe Apps:           [NOT FOUND]"
fi

if [ $CC_FOUND -eq 1 ]; then
    echo "  Creative Cloud:      OK"
else
    echo "  Creative Cloud:      [MISSING]"
fi

if [ $CEP_FOUND -eq 1 ]; then
    echo "  CEPHtmlEngine:       OK"
else
    echo "  CEPHtmlEngine:       [MISSING]"
fi

if [ $EXT_SYS -eq 1 ]; then
    echo "  System ext dir:      OK"
else
    echo "  System ext dir:      Not found"
fi

if [ $EXT_USER -eq 1 ]; then
    echo "  User ext dir:        OK"
else
    echo "  User ext dir:        Not found"
fi
echo ""

# ---- Advice ----
echo "============================================"
echo "                 ADVICE"
echo "============================================"
echo ""

if [ $APP_FOUND -eq 0 ] && [ $APP_OLD -eq 1 ]; then
    echo "  Adobe apps too old. Plugin requires 2022 or later."
    echo "  Update your Adobe apps."
    echo ""
fi
if [ $APP_FOUND -eq 0 ] && [ $APP_OLD -eq 0 ]; then
    echo "  No Adobe apps found."
    echo ""
fi
if [ $APP_FOUND -eq 1 ] && [ $CC_FOUND -eq 1 ] && [ $CEP_FOUND -eq 1 ]; then
    echo "  Environment OK. Installer and manual install both work."
    echo ""
fi
if [ $APP_FOUND -eq 1 ] && [ $CC_FOUND -eq 0 ] && [ $CEP_FOUND -eq 1 ]; then
    echo "  Creative Cloud missing but CEPHtmlEngine exists."
    echo "  Installer may fail. Use manual install:"
    echo "  Copy plugin folder to extensions directory."
    echo ""
fi
if [ $APP_FOUND -eq 1 ] && [ $CEP_FOUND -eq 0 ]; then
    echo "  CEPHtmlEngine not found. CEP plugins cannot run."
    echo "  Your Adobe apps may be stripped/lite versions."
    echo "  Install full Adobe apps with Creative Cloud."
    echo ""
fi

echo "============================================"
echo "  Please screenshot and send to the developer"
echo "============================================"
echo ""
read -p "Press Enter to exit..."
