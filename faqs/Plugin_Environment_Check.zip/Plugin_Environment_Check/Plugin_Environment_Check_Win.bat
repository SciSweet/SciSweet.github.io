@echo off
setlocal EnableDelayedExpansion
title CEP Environment Check

echo ============================================
echo        CEP Plugin Environment Check
echo ============================================
echo.

set CC_FOUND=0
set CEP_FOUND=0
set EXT_SYS=0
set EXT_USER=0
set PDM_ANY=0
set APP_FOUND=0
set APP_OLD=0

set "PF=%ProgramFiles%"
set "PFx86=%ProgramFiles(x86)%"

:: ---- Adobe Apps (2022+) ----
echo [1/5] Checking Adobe Apps...

for /d %%D in ("!PF!\Adobe\Adobe *") do (
    set "NAME=%%~nxD"
    set "YEAR="
    for %%Y in (2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028) do (
        echo !NAME! | findstr /l "%%Y" >nul 2>&1
        if not errorlevel 1 set "YEAR=%%Y"
    )
    if defined YEAR (
        if !YEAR! GEQ 2022 (
            echo       [OK] !NAME!
            set APP_FOUND=1
        ) else (
            echo       [OLD] !NAME! (requires 2022 or later^)
            set APP_OLD=1
        )
    )
)

if !APP_FOUND!==0 if !APP_OLD!==1 (
    echo       [!!] Only old Adobe apps found. Plugin requires 2022+.
)
if !APP_FOUND!==0 if !APP_OLD!==0 (
    echo       [!!] No Adobe apps found.
)
echo.

:: ---- Creative Cloud ----
echo [2/5] Checking Creative Cloud Desktop App...

if exist "!PF!\Adobe\Adobe Creative Cloud\ACC\Creative Cloud.exe" (
    echo       [OK] Found in Program Files
    set CC_FOUND=1
)
if exist "!PFx86!\Adobe\Adobe Creative Cloud\ACC\Creative Cloud.exe" (
    echo       [OK] Found in Program Files x86
    set CC_FOUND=1
)
if !CC_FOUND!==0 (
    echo       [MISSING] Creative Cloud Desktop App NOT found
    echo       Plugin installer requires this. Try manual install.
)
echo.

:: ---- CEPHtmlEngine ----
echo [3/5] Checking CEPHtmlEngine...
echo       Searching... please wait

for /f "delims=" %%F in ('where /r "!PF!\Adobe" CEPHtmlEngine.exe 2^>nul') do (
    echo       [OK] %%F
    set CEP_FOUND=1
)
if not "!PFx86!"=="!PF!" (
    for /f "delims=" %%F in ('where /r "!PFx86!\Adobe" CEPHtmlEngine.exe 2^>nul') do (
        echo       [OK] %%F
        set CEP_FOUND=1
    )
)
for /f "delims=" %%F in ('where /r "!PF!\Common Files\Adobe" CEPHtmlEngine.exe 2^>nul') do (
    echo       [OK] %%F
    set CEP_FOUND=1
)
if not "!PFx86!"=="!PF!" (
    for /f "delims=" %%F in ('where /r "!PFx86!\Common Files\Adobe" CEPHtmlEngine.exe 2^>nul') do (
        echo       [OK] %%F
        set CEP_FOUND=1
    )
)

if !CEP_FOUND!==0 (
    echo       [MISSING] CEPHtmlEngine NOT found
    echo       CEP plugins CANNOT run. Adobe may be a lite version.
)
echo.

:: ---- CEP extensions dirs ----
echo [4/5] Checking CEP extensions directories...

if exist "!PFx86!\Common Files\Adobe\CEP\extensions" (
    echo       [OK] System ext dir found (x86^)
    set EXT_SYS=1
)
if exist "!PF!\Common Files\Adobe\CEP\extensions" (
    echo       [OK] System ext dir found
    set EXT_SYS=1
)
if exist "!APPDATA!\Adobe\CEP\extensions" (
    echo       [OK] User ext dir found
    set EXT_USER=1
)
if !EXT_SYS!==0 if !EXT_USER!==0 (
    echo       [MISSING] No CEP extensions directory found
)
echo.

:: ---- PlayerDebugMode ----
echo [5/5] Checking PlayerDebugMode...

for %%V in (6 7 8 9 10 11 12) do (
    for /f "tokens=*" %%L in ('reg query "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode 2^>nul ^| findstr /l "PlayerDebugMode"') do (
        set "LINE=%%L"
        for %%T in (!LINE!) do set "VAL=%%T"
        echo       CSXS.%%V = !VAL!
        set PDM_ANY=1
    )
)
if !PDM_ANY!==0 (
    echo       Not set (OK for signed plugins^)
)
echo.

:: ---- Summary ----
echo ============================================
echo                  SUMMARY
echo ============================================
echo.
if !APP_FOUND!==1 (
    echo   Adobe Apps (2022+^):  OK
) else if !APP_OLD!==1 (
    echo   Adobe Apps:           [TOO OLD] Need 2022 or later
) else (
    echo   Adobe Apps:           [NOT FOUND]
)
if !CC_FOUND!==1 (
    echo   Creative Cloud:      OK
) else (
    echo   Creative Cloud:      [MISSING]
)
if !CEP_FOUND!==1 (
    echo   CEPHtmlEngine:       OK
) else (
    echo   CEPHtmlEngine:       [MISSING]
)
if !EXT_SYS!==1 (
    echo   System ext dir:      OK
) else (
    echo   System ext dir:      Not found
)
if !EXT_USER!==1 (
    echo   User ext dir:        OK
) else (
    echo   User ext dir:        Not found
)
echo.

:: ---- Advice ----
echo ============================================
echo                  ADVICE
echo ============================================
echo.
if !APP_FOUND!==0 if !APP_OLD!==1 (
    echo   Adobe apps too old. Plugin requires 2022 or later.
    echo   Update your Adobe apps.
    echo.
)
if !APP_FOUND!==0 if !APP_OLD!==0 (
    echo   No Adobe apps found.
    echo.
)
if !APP_FOUND!==1 if !CC_FOUND!==1 if !CEP_FOUND!==1 (
    echo   Environment OK. Installer and manual install both work.
    echo.
)
if !APP_FOUND!==1 if !CC_FOUND!==0 if !CEP_FOUND!==1 (
    echo   Creative Cloud missing but CEPHtmlEngine exists.
    echo   Installer may fail. Use manual install:
    echo   Copy plugin folder to extensions directory.
    echo.
)
if !APP_FOUND!==1 if !CEP_FOUND!==0 (
    echo   CEPHtmlEngine not found. CEP plugins cannot run.
    echo   Your Adobe apps may be stripped/lite versions.
    echo   Install full Adobe apps with Creative Cloud.
    echo.
)

echo ============================================
echo   Please screenshot and send to the developer
echo ============================================
echo.
pause
endlocal
